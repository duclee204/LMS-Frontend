import { AddExamComponent } from './addexam.component';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [AddExamComponent],
})
export class AddexamModule {}
